Left Joycon is the Nunchuk right is the Wiimote 
You need to install better joy for this to work 
Here is a tut https://www.youtube.com/watch?v=vh0XMr_11Mk&t=27s
Now that's better joy is working, load my config file into dolphin to do this look in the top left corner in dolphin select file then open user folder, select config then profiles then drag and drop my file in.


One more thing in better joy if the joycons are more vertical than the work together, but if they are on the side then they are separate you want them separate for this to work for more info you can watch this tut https://www.youtube.com/watch?v=zpRzWlkxJAg